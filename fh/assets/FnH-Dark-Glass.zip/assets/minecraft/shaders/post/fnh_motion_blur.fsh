#version 330

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

in vec2 texCoord;

layout(std140) uniform MotionBlurConfig {
    float BlendFactor;
};

out vec4 fragColor;

void main() {
    vec4 curr = texture(InSampler, texCoord);
    vec4 prev = texture(PrevSampler, texCoord);
    vec3 mixed = prev.a < 0.5 ? curr.rgb : mix(curr.rgb, prev.rgb, BlendFactor);
    fragColor = vec4(mixed, 1.0);
}
